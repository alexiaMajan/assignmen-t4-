class Plot {
    private int x;
    private int y;
    private int width;
    private int depth;

    public Plot(int x, int y, int width, int depth) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.depth = depth;
    }

    public Plot(Plot plot) {
        this.x = plot.x;
        this.y = plot.y;
        this.width = plot.width;
        this.depth = plot.depth;
    }

	public void setX(int x) {
		this.x = x;
	}
	public int getX() {
		return x;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getY () {
		return y;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getWidth() {
		return width;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public int getDepth() {
		return depth;
	}

	public boolean overlaps(Plot plot) {
		boolean overlaps = true;

		if ((x + width ) < plot.getX() && ( y + width) < plot.getY()
				&& (plot.getY() + plot.getWidth()) < y && (plot.getX() + plot.getWidth()) < x
				&& x > plot.getY() && (x + width ) > (plot.getY() + plot.getWidth())
				&& ((plot.getX() + plot.getWidth()) > ( y  +  width )) && (plot.getX() > x )){
			overlaps = false;
		}
		return overlaps;

	 
	}
	
public boolean encompasses(Plot plot) {
	
	boolean encompasses = true;
	if ( x <= plot.x && x + width >= plot.x + plot.width &&
        y <= plot.y && y + depth >= plot.y + plot.depth)
		encompasses = false;
	
	return encompasses;
			
}


@Override
public String toString() {
    return x + "," + y + "," + width + "," + depth;
}




}




