
public class ManagementCompany {
	 private String companyName;
	    private String taxId;
	    private double fee;
	    private Property[] properties;
	    private Plot plot;
	    private int numberOfProperties;
	    public final int MAX_PROPERTY = 5;
	    public  final int MGMT_WIDTH = 10;
	    public  final int MGMT_DEPTH = 10;
	    
	public ManagementCompany() {
		this.companyName = "";
		this.taxId = "";
		this.plot = new Plot(0, 0, 1, 1);
		this.properties = new Property[MAX_PROPERTY];
	}

	public ManagementCompany(String companyName, String taxId, double fee) {
		this.companyName = companyName;
		this.taxId = taxId;
		this.fee = fee;
		this.plot = new Plot(0, 0, 10, 10);
		this.properties = new Property[MAX_PROPERTY];
	}

	public ManagementCompany(String companyName, String taxId, double fee, int x, int y, int width, int depth) {
		this.companyName = companyName;
		this.taxId = taxId;
		this.fee = fee;
		this.plot = new Plot(x, y, width, depth);
		this.properties = new Property[MAX_PROPERTY];
	}

	public ManagementCompany(ManagementCompany otherCompany) {
		this.companyName = otherCompany.companyName;
		this.taxId = otherCompany.taxId;
		this.fee = otherCompany.fee;
		this.plot = otherCompany.plot;
		this.properties = otherCompany.properties;
	}

	public void setName(String companyName) {
		this.companyName = companyName;
	}

	public void setTaxID(String taxId) {
		this.taxId = taxId;
	}

	public void setMgmFee(double fee) {
		this.fee = fee;
	}

	public void setPlot(Plot plot) {
		this.plot = new Plot(plot);
	}

	public String getName() {
		return companyName;
	}

	public String getTaxID() {
		return taxId;
	}

	public double fee() {
		return fee;
	}

	public Plot getPlot() {
		return new Plot(plot);
	}
	 public int addProperty(Property property) {
			// TODO Auto-generated method stub
			return 0;
		}


	    public int addProperty(String name, String city, double rent, String owner, Plot plot) {
	        if (numberOfProperties >= MAX_PROPERTY) {
	            return -1; 
	        }
	        if (name == null || city == null || owner == null || plot == null) {
	            return -2; 
	        }
	        if (!this.plot.encompasses(plot)) {
	            return -3;
	        }
	        for (int i = 0; i < numberOfProperties; i++) {
	            if (properties[i].getPlot().overlaps(plot)) {
	                return -4;
	            }
	        }
	        properties[numberOfProperties] = new Property();
	        numberOfProperties++;
	        return numberOfProperties - 1;
	    }


	
	
	
	public Property getHighestRentPropperty() {
		  if (numberOfProperties == 0) {
	            return null; // No properties in the array
	        }

	        Property highestRentProperty = properties[0]; // Initialize with the first property

	        for (int i = 1; i < numberOfProperties; i++) {
	            if (properties[i].getRentAmount() > highestRentProperty.getRentAmount()) {
	                highestRentProperty = properties[i]; // Update with the property with higher rent
	            }
	        }

	        return highestRentProperty;
	}



	
	public double getTotalRent() {
		int total = 0; // track sum

		// property
		Property house = new Property();

		for (int i = 0; i < properties.length; i++) {
			properties[i] = house;
			total += properties[i].getRentAmount();
		}
		return total;
	}

    public void removeLastProperty() {
        if (numberOfProperties > 0) {
            properties[numberOfProperties - 1] = null;
            numberOfProperties--;
        }
    }

    public boolean isPropertiesFull() {
        return numberOfProperties >= MAX_PROPERTY;
    }
    public int getPropertiesCount() {
        return numberOfProperties;
    }

    public boolean isManagementFeeValid() {
        return fee >= 0 && fee <= 100;
    }
    @Override
    public String toString() {

        StringBuilder result = new StringBuilder();
        result.append("List of the properties for ").append(companyName).append(", taxID: ").append(taxId).append("\n");

        for (int i = 0; i < numberOfProperties; i++) {
            Property property = properties[i];
            result.append("______________________________________________________\n");
            result.append("Property Name: ").append(property.getPropertyName()).append("\n");
            result.append("Located in ").append(property.getCity()).append("\n");
            result.append("Belonging to: ").append(property.getOwner()).append("\n");
            result.append("Rent Amount: ").append(property.getRentAmount()).append("\n");
        }

        result.append("______________________________________________________\n");
        result.append("total management Fee: ").append(String.format("%.2f", fee())).append("\n");

        return result.toString();
    }
        
    
}
	