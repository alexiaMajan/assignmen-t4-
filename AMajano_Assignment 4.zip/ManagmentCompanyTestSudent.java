import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ManagmentCompanyTestSudent {
	Property sampleProperty;
	ManagementCompany Mgmtco ; 
	
	@Before
	public void setUp() throws Exception {
		Mgmtco= new ManagementCompany("Alliance", "1234567",10);
	}

	@After
	public void tearDown() throws Exception {
		Mgmtco=null;
	}

	@Test
	public void testAddProperty() {
		sampleProperty = new Property ("golfing", "eliz", 4400, "alex charter ",1,2,3,3);		 
		assertEquals(Mgmtco.addProperty(sampleProperty),0,0);	//property has been successfully added to index 0
	}
	
	@Test
	public void testGetPropertiesCount() {
		sampleProperty = new Property ("golfing", "eliz", 4400, "alex charter ",1,2,3,3);		 
		assertEquals(Mgmtco.addProperty(sampleProperty),0,0);	
		assertEquals(Mgmtco.getPropertiesCount(), 1);
	}

	@Test
	public void testToString() {
		sampleProperty = new Property ("golfing", "eliz", 4400, "alex charter ",1,2,3,3);
		assertEquals(Mgmtco.addProperty(sampleProperty), 0);	//property has been successfully added to index 0
		String expectedString = "List of the properties for Alliance, taxID: 1234567\n"
				+ "______________________________________________________\n"
				+ "golfing,eliz,alex charter,4400\n"
				+ "______________________________________________________\n"
				+"\n"
				+ " total management Fee: 440.00";
		System.out.println(expectedString);
		System.out.println(Mgmtco.toString());
		assertEquals(expectedString, Mgmtco.toString());
				
	}

}
