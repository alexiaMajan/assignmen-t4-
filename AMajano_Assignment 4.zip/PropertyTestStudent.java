
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class PropertyTestStudent {
	Property propertyTwo;

	@BeforeEach
	void setUp() throws Exception {
		propertyTwo = new Property("Property Mgmt", "Rockville", 1000.00, "house");
	}

	@AfterEach
	void tearDown() throws Exception {
		propertyTwo = null;
	}

	@Test
	void testGetPropertyName() {
		assertEquals("Property Mgmt", propertyTwo.getPropertyName());
	}

	@Test
	void testGetRentAmount() {
		assertEquals(1000.00, propertyTwo.getRentAmount());
	}

	@Test
	void testGetPlot() {
		assertEquals(1, propertyTwo.getPlot().getX());
		assertEquals(1, propertyTwo.getPlot().getY());
		assertEquals(2, propertyTwo.getPlot().getWidth());
		assertEquals(2, propertyTwo.getPlot().getDepth());
	}

	@Test
	void testToString() {
		assertEquals("Property Mgmt,Rockville, house ,1000.0",propertyTwo.toString());	
	}

}
