
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

class PlotTestStudent {

private Plot plot2, plot4;

	@Before
	public void setUp() throws Exception {
		plot2 = new Plot(1, 1, 6, 6);
		plot4 = new Plot(1, 2, 6, 2);
	}

	@After
	public void tearDown() throws Exception {
		plot2 = plot4 = null;
	}

	@Test
	public void testOverlaps() {
		assertTrue(plot2.overlaps(plot4)); // plot5 is entirely inside plot1
	}
	
	@Test
	public void testToString() {
		assertEquals("2,5,5,2",plot4.toString());	
	}

}
